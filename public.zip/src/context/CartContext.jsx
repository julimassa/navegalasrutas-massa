import React, { createContext, useState } from "react";

export const CartContext = createContext();

export function CartProvider({ children }) {
  const [cart, setCart] = useState([]);

  // 🔹 Agregar producto (si ya está, suma 1 hasta máximo 3)
  const addToCart = (product) => {
    const exist = cart.find((item) => item.id === product.id);
    if (exist) {
      setCart(
        cart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: Math.min(item.quantity + 1, 3) }
            : item
        )
      );
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  // 🔹 Incrementar cantidad (máx 3)
  const incQty = (id) => {
    setCart((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, quantity: Math.min((item.quantity ?? 0) + 1, 3) }
          : item
      )
    );
  };

  // 🔹 Decrementar cantidad (si queda en 0, se elimina)
  const decQty = (id) => {
    setCart((prev) =>
      prev
        .map((item) =>
          item.id === id
            ? { ...item, quantity: Math.max((item.quantity ?? 0) - 1, 0) }
            : item
        )
        .filter((item) => (item.quantity ?? 0) > 0)
    );
  };

  // 🔹 Eliminar producto
  const removeFromCart = (id) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  // 🔹 Vaciar carrito
  const clearCart = () => {
    setCart([]);
  };

  // 🔹 Cantidad total de productos
  const totalQuantity = cart.reduce((acc, item) => acc + (item.quantity ?? 0), 0);

  // 🔹 Precio total
  const totalPrice = cart.reduce(
    (acc, item) => acc + (item.price ?? 0) * (item.quantity ?? 0),
    0
  );

  // 👇 Aquí va el famoso value con TODO lo que expone el contexto
  const value = {
    cart,
    addToCart,
    removeFromCart,
    clearCart,
    incQty,
    decQty,
    totalQuantity,
    totalPrice,
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}
