// src/pages/Home.jsx
export default function Home(){
  return (
    <main style={{maxWidth:1100, margin:"0 auto", padding:"12px"}}>
      {/* Banner (reemplazá el src por tu imagen real en /public/img/) */}
      <section style={{marginBottom:16}}>
        <img
          src="/img/banner1.jpg"   // poné tu archivo, ej: /img/banner.jpg
          alt="Banner"
          style={{width:"100%", height:"auto", borderRadius:12}}
        />
      </section>

      {/* Galería simple (reemplazá por tus fotos) */}
      <section style={{
        display:"grid",
        gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))",
        gap:12
      }}>
        <img src="/img/foto-1.jpg" alt="Foto 1"
             style={{width:"100%", height:220, objectFit:"cover", borderRadius:12}} />
        <img src="/img/foto-2.jpg" alt="Foto 2"
             style={{width:"100%", height:220, objectFit:"cover", borderRadius:12}} />
      </section>
    </main>
  );
}
